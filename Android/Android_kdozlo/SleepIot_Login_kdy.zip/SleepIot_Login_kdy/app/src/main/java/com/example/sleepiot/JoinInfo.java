package com.example.sleepiot;

import com.google.gson.annotations.SerializedName;

public class JoinInfo {

    //@SerializedName("username")
    private String username;

    //@SerializedName("password")
    private String password;

    //@SerializedName("realname")
    private String realname;

    //@SerializedName("email")
    private String email;

    //@SerializedName("address")
    private String address;

    //@SerializedName("phoneNum")
    private String phoneNum;

    //@SerializedName("c_phoneNum")
    private String c_phoneNum;


    public JoinInfo(String username, String password, String realname, String email, String address, String phoneNum, String c_phoneNum) {
        this.username = username;
        this.password = password;
        this.realname = realname;
        this.email = email;
        this.address = address;
        this.phoneNum = phoneNum;
        this.c_phoneNum = c_phoneNum;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", realname='" + realname + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", phoneNum='" + phoneNum + '\'' +
                ", c_poneNum='" + c_phoneNum + '\'' +
                '}';
    }
}
